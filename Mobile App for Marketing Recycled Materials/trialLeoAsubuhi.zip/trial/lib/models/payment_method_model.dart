enum PaymentMethod {
  m_pesa,
  artel_money,
  tigo_pesa,
  halo_pesa,
  credit_card,
}
